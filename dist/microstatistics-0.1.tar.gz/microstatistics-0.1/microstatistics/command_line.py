import microstatistics

def main():
	microstatistics.run()
