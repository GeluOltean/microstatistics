microStatistics
---------------

A package for processing micropalaeontological and palaecological data using various statistical indices. Used through a Qt5 interface.

Launched with microstatistics-start
